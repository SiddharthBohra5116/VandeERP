const mongoose = require('mongoose');
const { generateRollNumber } = require('../utils/rollNumberHelper');

const teacherSchema = new mongoose.Schema({

  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },

  rollNumber: {
    type: String,
    unique: true,
    trim: true
  },

  courses: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course'
  }],

  qualification: {
    type: String,
    default: ''
  },

  experienceYears: {
    type: Number,
    default: 0
  },

  salary: {
    type: Number,
    default: 0
  },

  joiningDate: {
    type: Date,
    default: Date.now
  },

  status: {
    type: String,
    enum: ['Active', 'Inactive'],
    default: 'Active'
  }

}, { timestamps: true });

teacherSchema.pre('save', async function(next) {
  try {
    await generateRollNumber(this, 'teacher', 'TCH');
    next();
  } catch (err) {
    next(err);
  }
});

teacherSchema.set('toJSON', { virtuals: true });
teacherSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('Teacher', teacherSchema);